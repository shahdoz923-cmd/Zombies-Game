const Lobby={t:0,init(){},update(dt){this.t+=dt;Game.lobbyTime=this.t}};
